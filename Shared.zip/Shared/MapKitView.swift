//
//  MapKitView.swift
//  Crap Tracker (iOS)
//
//  Created by Trevor Schmidt on 10/18/21.
//

import SwiftUI
import MapKit
import CoreLocation
import Kingfisher

struct MapKitView: View {
    @ObservedObject var manager: LocationManager
    var poops: [PoopModel]
    @State private var commentsAlertIsPresented = false
    @State private var clickedUsername = ""
    @State private var clickedComments = ""
    @State private var clickedFormattedDateTime = ""
    @State private var clickedUserId = ""
    @State private var clickedDateTime = ""
    
    var body: some View {
        Map(coordinateRegion: $manager.region, showsUserLocation: true, annotationItems: poops) { poop in
            MapAnnotation(coordinate: CLLocationCoordinate2D(latitude: poop.lat, longitude: poop.long)) {
                Button {
                    clickedUserId = poop.userId
                    clickedUsername = poop.username
                    clickedComments = poop.comments
                    clickedFormattedDateTime = poop.dateTime.fromLongToShort()
                    clickedDateTime = poop.dateTime
                    commentsAlertIsPresented.toggle()
                } label: {
                    if let profilePicUrl = poop.profilePicUrl {
                        KFImage(URL(string: profilePicUrl)!)
                            .resizable()
                            .scaledToFit()
                            .frame(width: 40, height: 40)
                            .cornerRadius(20)
                            .overlay(Circle().stroke(.white, lineWidth: 2))
                    } else {
                        ZStack {
                            Circle()
                                .fill(.gray)
                                .opacity(50)
                                .overlay(Circle().stroke(.white, lineWidth: 2))
                                .shadow(radius: 20)
                                .frame(width: 40, height: 40)
                            Text("\(String(poop.username.first!))")
                                .font(.headline)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .frame(width: 40, height: 40)
                        }
                    }
                }
            }
        }
        .alert(isPresented: $commentsAlertIsPresented, content: {
            
            if let userId = FirebaseAuthService.shared.getUserId(), userId == clickedUserId {
                return Alert(title: Text("\(clickedUsername)"),
                             message: Text("\(clickedFormattedDateTime)\n\n\(clickedComments)"),
                             primaryButton: .default(Text("Nice Crap!")),
                             secondaryButton: .destructive(Text("Delete")) {
                                FirebaseDatabaseService.shared.deletePin(userId: userId, dateTime: clickedDateTime)
                            }
                      )
            } else {
                return Alert(title: Text("\(clickedUsername)"),
                      message: Text("\(clickedFormattedDateTime)\n\n\(clickedComments)"),
                      dismissButton: .default(Text("Nice Crap!")))
            }
            
            
        })
    }
    
}

class LocationManager: NSObject,CLLocationManagerDelegate, ObservableObject {
    @Published var region = MKCoordinateRegion()
    private let manager = CLLocationManager()
    
    private var loaded = false
    
    override init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestWhenInUseAuthorization()
        manager.startUpdatingLocation()
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if !loaded {
            locations.last.map {
                region = MKCoordinateRegion(
                    center: CLLocationCoordinate2D(latitude: $0.coordinate.latitude, longitude: $0.coordinate.longitude),
                    span: MKCoordinateSpan(latitudeDelta: 0.005, longitudeDelta: 0.005)
                )
            }
        }
        loaded = true
    }
    
    
}

//struct MapKitView_Previews: PreviewProvider {
//    static var previews: some View {
//        MapKitView()
//    }
//}
