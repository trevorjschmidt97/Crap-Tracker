//
//  Model.swift
//  Crap Tracker
//
//  Created by Trevor Schmidt on 9/28/21.
//

import Foundation

struct Model {
    var count = 1
}
