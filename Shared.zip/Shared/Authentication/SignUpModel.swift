//
//  SignUpModel.swift
//  Crap Tracker
//
//  Created by Trevor Schmidt on 9/29/21.
//

import Foundation

struct SignUpModel {
    var username: String = ""
    var email: String = ""
    var password: String = ""
}
